_addon.name = 'trailmap'
_addon.author = 'Codex'
_addon.version = '1.0.7'
_addon.commands = {'trailmap', 'tm'}

require('logger')
require('tables')

local texts = require('texts')
local config = require('config')
local res = require('resources')

local defaults = {
    enabled = true,
    visible = true,
    width = 61,
    height = 31,
    scale = 1.2,
    min_step = 0.75,
    opacity = 235,
    draw_delay = 0.08,
    center_on_player = false,
    erase_on_backtrack = true,
    erase_radius = 4,
    erase_tail_ignore = 6,
    auto_save = true,
    save_interval = 20,
    pos = {x = 40, y = 80},
    text = {
        visible = true,
        font = 'Consolas',
        fonts = {'Consolas'},
        size = 8,
        red = 210,
        green = 235,
        blue = 255,
        alpha = 255,
    },
    bg = {
        visible = true,
        red = 0,
        green = 0,
        blue = 0,
        alpha = 235,
    },
    flags = {
        draggable = true,
        bold = false,
        italic = false,
    },
}

local map_version = 4
local settings = config.load(defaults)
local overlay = nil
local test_overlay = nil
local prim_prefix = 'trailmap_'
local active_primitives = {}
local prim_cell_count = 0
local prim_ok = nil
local trail = {}
local path = {}
local zone_id = nil
local origin = nil
local last_pos = nil
local last_draw = 0
local last_save = 0
local dirty = false

local function chat(message)
    if windower and windower.add_to_chat then
        windower.add_to_chat(207, '[trailmap] '..tostring(message))
    else
        notice(tostring(message))
    end
end

local function prim_delete(name)
    if windower and windower.prim and windower.prim.delete then
        pcall(windower.prim.delete, name)
    end
    active_primitives[name] = nil
end

local function set_prim(name, x, y, w, h, a, r, g, b, visible)
    if not windower or not windower.prim or prim_ok == false then
        prim_ok = false
        return false
    end
    
    if not active_primitives[name] then
        local ok = pcall(windower.prim.create, name)
        if not ok then
            prim_ok = false
            return false
        end
        active_primitives[name] = true
    end
    
    local ok1 = pcall(windower.prim.set_position, name, x, y)
    local ok2 = pcall(windower.prim.set_size, name, w, h)
    local ok3 = pcall(windower.prim.set_color, name, a, r, g, b)
    local ok4 = pcall(windower.prim.set_visibility, name, visible)
    
    if not (ok1 and ok2 and ok3 and ok4) then
        prim_ok = false
        return false
    end
    
    prim_ok = true
    return true
end

local function prim_rect(name, x, y, w, h, a, r, g, b)
    return set_prim(name, x, y, w, h, a, r, g, b, true)
end

local function clear_primitives()
    for name, _ in pairs(active_primitives) do
        prim_delete(name)
    end
    active_primitives = {}
    prim_cell_count = 0
end

local function normalize_settings()
    settings.pos = settings.pos or {}
    settings.pos.x = tonumber(settings.pos.x or settings.x) or defaults.pos.x
    settings.pos.y = tonumber(settings.pos.y or settings.y) or defaults.pos.y
    settings.x = settings.pos.x
    settings.y = settings.pos.y

    settings.text = settings.text or {}
    settings.text.visible = true
    settings.text.font = settings.text.font or defaults.text.font
    settings.text.fonts = settings.text.fonts or defaults.text.fonts
    settings.text.size = tonumber(settings.text.size) or defaults.text.size

    settings.bg = settings.bg or {}
    settings.bg.visible = true
    settings.opacity = math.max(0, math.min(255, tonumber(settings.opacity) or defaults.opacity))
    settings.bg.alpha = settings.opacity

    settings.width = math.max(15, math.min(121, math.floor(tonumber(settings.width) or defaults.width)))
    settings.height = math.max(9, math.min(61, math.floor(tonumber(settings.height) or defaults.height)))
    if settings.width % 2 == 0 then settings.width = settings.width + 1 end
    if settings.height % 2 == 0 then settings.height = settings.height + 1 end

    settings.scale = math.max(0.1, tonumber(settings.scale) or defaults.scale)
    settings.min_step = math.max(0.1, tonumber(settings.min_step) or defaults.min_step)
    settings.erase_radius = math.max(1, tonumber(settings.erase_radius) or defaults.erase_radius)
    settings.erase_tail_ignore = math.max(settings.erase_radius + 2, tonumber(settings.erase_tail_ignore) or defaults.erase_tail_ignore)
end

local function set_visible(visible)
    if not overlay then return end

    if visible then
        if overlay.show then overlay:show() end
        if overlay.visible then overlay:visible(true) end
    else
        if overlay.hide then overlay:hide() end
        if overlay.visible then overlay:visible(false) end
    end
end

local function key_for_cell(x, y)
    return tostring(x)..':'..tostring(y)
end

local function same_cell(cell, x, y)
    return cell and cell.x == x and cell.y == y
end

local function add_trail_count(x, y, amount)
    local key = key_for_cell(x, y)
    local count = (trail[key] or 0) + amount
    trail[key] = count > 0 and count or nil
end

local function push_cell(x, y)
    path[#path + 1] = {x = x, y = y}
    add_trail_count(x, y, 1)
end

local function pop_cell()
    local cell = path[#path]
    if not cell then return end
    add_trail_count(cell.x, cell.y, -1)
    path[#path] = nil
end

local function record_cell(x, y)
    local current = path[#path]
    if same_cell(current, x, y) then return end

    if settings.erase_on_backtrack then
        local radius_sq = settings.erase_radius * settings.erase_radius
        local newest_index = #path - settings.erase_tail_ignore
        local nearest_index = nil
        local nearest_dist = radius_sq + 1

        for i = 1, newest_index do
            local cell = path[i]
            local dx = cell.x - x
            local dy = cell.y - y
            local dist = dx * dx + dy * dy
            if dist <= radius_sq and dist <= nearest_dist then
                nearest_index = i
                nearest_dist = dist
            end
        end

        if nearest_index then
            while #path > nearest_index do
                pop_cell()
            end
            return
        end
    end

    push_cell(x, y)
end

local function rebuild_trail_from_path()
    trail = {}
    for _, cell in ipairs(path) do
        if cell.x and cell.y then
            add_trail_count(cell.x, cell.y, 1)
        end
    end
end

local function normalize_loaded_trail()
    local loaded = trail
    trail = {}
    for key, value in pairs(loaded) do
        if type(value) == 'number' and value > 0 then
            trail[key] = value
        elseif value then
            trail[key] = 1
        end
    end
end

local function get_player_pos()
    local player = windower.ffxi.get_mob_by_target('me')
    if not player then return nil end
    return {x = player.x, y = player.y}
end

local function cell_from_world(pos)
    if not origin or not pos then return nil end
    local dx = pos.x - origin.x
    local dy = pos.y - origin.y
    local x = math.floor((dy / settings.scale) + 0.5)
    local y = math.floor((dx / settings.scale) + 0.5)
    return x, y
end

local function distance(a, b)
    if not a or not b then return math.huge end
    local dx = a.x - b.x
    local dy = a.y - b.y
    return math.sqrt(dx * dx + dy * dy)
end

local function save_trail()
    if not settings.auto_save or not zone_id then return end

    local file = io.open(windower.addon_path..'data/trail_'..tostring(zone_id)..'.lua', 'w+')
    if not file then
        warning('trailmap: could not save trail data.')
        return
    end

    file:write('return '..table.tovstring({
        map_version = map_version,
        zone_id = zone_id,
        origin = origin,
        path = path,
        trail = trail,
    })..'\n')
    file:close()
    dirty = false
    last_save = os.clock()
end

local function load_trail(new_zone_id)
    trail = {}
    path = {}
    origin = nil
    last_pos = nil
    zone_id = new_zone_id

    local ok, data = pcall(dofile, windower.addon_path..'data/trail_'..tostring(zone_id)..'.lua')
    if ok and type(data) == 'table' and data.zone_id == zone_id then
        if data.map_version ~= map_version then
            return
        end

        origin = data.origin
        path = data.path or {}
        if data.path then
            rebuild_trail_from_path()
        else
            trail = data.trail or {}
            normalize_loaded_trail()
        end
    end
end

local function make_overlay()
    normalize_settings()
    if overlay and overlay.destroy then overlay:destroy() end

    overlay = texts.new(' [trailmap] ', settings)
    overlay:pos(settings.pos.x, settings.pos.y)
    overlay:text(' [trailmap] ')
    if overlay.bg_visible then overlay:bg_visible(true) end
    if overlay.bg_alpha then overlay:bg_alpha(settings.opacity) end
    set_visible(settings.visible)
end

local function reset_trail()
    trail = {}
    path = {}
    origin = get_player_pos()
    last_pos = nil
    dirty = true
    save_trail()
end

local function clear_trail()
    trail = {}
    path = {}
    last_pos = nil
    dirty = true
    save_trail()
end

local function plot_line(from_x, from_y, to_x, to_y)
    if not from_x or not from_y or not to_x or not to_y then return end

    local dx = math.abs(to_x - from_x)
    local sx = from_x < to_x and 1 or -1
    local dy = -math.abs(to_y - from_y)
    local sy = from_y < to_y and 1 or -1
    local err = dx + dy

    while true do
        record_cell(from_x, from_y)
        if from_x == to_x and from_y == to_y then break end

        local e2 = 2 * err
        if e2 >= dy then
            err = err + dy
            from_x = from_x + sx
        end
        if e2 <= dx then
            err = err + dx
            from_y = from_y + sy
        end
    end
end

local function render(current_pos)
    if not settings.visible or not settings.enabled then return end
    if not origin or not current_pos then return end

    -- Sync position from the draggable text box overlay in real-time
    if overlay then
        local ox, oy = overlay:pos()
        if ox and oy and (ox ~= settings.pos.x or oy ~= settings.pos.y) then
            settings.pos.x = ox
            settings.pos.y = oy
            settings.x = ox
            settings.y = oy
            dirty = true
        end
    end

    local current_x, current_y = cell_from_world(current_pos)
    local cell_size = 5
    local pad = 4
    local prim_x = settings.pos.x
    local title_height = 18
    local prim_y = settings.pos.y + title_height
    local prim_w = settings.width * cell_size + pad * 2
    local prim_h = settings.height * cell_size + pad * 2

    if windower and windower.prim and prim_ok ~= false then
        set_prim(prim_prefix..'bg', prim_x, prim_y, prim_w, prim_h, settings.opacity, 0, 0, 0, true)
    end

    local half_w = math.floor(settings.width / 2)
    local half_h = math.floor(settings.height / 2)
    local center_x = settings.center_on_player and current_x or 0
    local center_y = settings.center_on_player and current_y or 0
    local left = center_x - half_w
    local top = center_y - half_h

    local cell_idx = 0

    for row = 0, settings.height - 1 do
        local y = top + row
        for col = 0, settings.width - 1 do
            local x = left + col
            local ch = ' '
            
            -- Draw start location "+" (a 5-cell cross) at relative cell (0, 0)
            local is_start = (x == 0 and y == 0) or
                             (x == -1 and y == 0) or
                             (x == 1 and y == 0) or
                             (x == 0 and y == -1) or
                             (x == 0 and y == 1)

            if is_start then
                ch = '+'
            elseif trail[key_for_cell(x, y)] then
                ch = '.'
            end

            if x == current_x and y == current_y then
                ch = '@'
            end

            if windower and windower.prim and prim_ok ~= false and ch ~= ' ' then
                cell_idx = cell_idx + 1
                local name = prim_prefix..'cell_'..tostring(cell_idx)

                -- Traveling breadcrumb defaults to a yellow shade
                local a, r, g, b = 255, 255, 235, 90
                
                if ch == '@' then
                    -- Current position coordinates default to cyan
                    r, g, b = 0, 255, 255
                elseif ch == '+' then
                    -- Start location cross is red
                    r, g, b = 255, 50, 50
                end

                set_prim(name, prim_x + pad + col * cell_size, prim_y + pad + row * cell_size, cell_size, cell_size, a, r, g, b, true)
            end
        end
    end

    -- Hide unused primitives in the pool
    if cell_idx > prim_cell_count then
        prim_cell_count = cell_idx
    elseif cell_idx < prim_cell_count then
        for i = cell_idx + 1, prim_cell_count do
            local name = prim_prefix..'cell_'..tostring(i)
            if active_primitives[name] then
                pcall(windower.prim.set_visibility, name, false)
            end
        end
    end

    -- Update title bar text with zone name and coordinates
    if overlay then
        local current_x_world = string.format("%.1f", current_pos.x)
        local current_y_world = string.format("%.1f", current_pos.y)
        local zone_name = ""
        local info = windower.ffxi.get_info()
        if info and info.zone then
            if res and res.zones and res.zones[info.zone] then
                zone_name = res.zones[info.zone].en or ""
            end
        end
        local label_text = ' [trailmap] '
        if zone_name ~= "" then
            label_text = label_text .. zone_name .. ' '
        end
        label_text = label_text .. '(' .. current_x_world .. ', ' .. current_y_world .. ') '
        overlay:text(label_text)
    end
end

local function tick()
    if not settings.enabled then return end

    local now = os.clock()
    if now - last_draw < settings.draw_delay then return end
    last_draw = now

    local info = windower.ffxi.get_info()
    if info and info.zone and info.zone ~= zone_id then
        load_trail(info.zone)
    end

    local pos = get_player_pos()
    if not pos then return end

    if not origin then
        origin = {x = pos.x, y = pos.y}
        dirty = true
    end

    if not last_pos or distance(last_pos, pos) >= settings.min_step then
        local old_x, old_y = cell_from_world(last_pos)
        local new_x, new_y = cell_from_world(pos)
        plot_line(old_x or new_x, old_y or new_y, new_x, new_y)
        last_pos = pos
        dirty = true
    end

    render(pos)

    if dirty and settings.auto_save and now - last_save >= settings.save_interval then
        save_trail()
    end
end

local function show_help()
    notice('trailmap commands:')
    notice('//tm show | hide | toggle | reset | clear | save | center | backtrack | status | debug | test | primtest | reloadbox')
    notice('//tm pos <x> <y>   //tm size <odd width> <odd height>')
    notice('//tm scale <yalms-per-cell>   //tm opacity <0-255>   //tm eraser [cells]')
end

local function show_status()
    settings.pos = settings.pos or {x = settings.x or 0, y = settings.y or 0}
    chat('visible='..tostring(settings.visible)..' enabled='..tostring(settings.enabled)..' zone='..tostring(zone_id))
    chat('pos='..tostring(settings.pos.x)..','..tostring(settings.pos.y)..' size='..tostring(settings.width)..'x'..tostring(settings.height)..' scale='..tostring(settings.scale)..' eraser='..tostring(settings.erase_on_backtrack)..' radius='..tostring(settings.erase_radius))
    chat('origin='..tostring(origin ~= nil)..' path_cells='..tostring(#path)..' opacity='..tostring(settings.opacity)..' overlay='..tostring(overlay ~= nil)..' test_overlay='..tostring(test_overlay ~= nil)..' prim='..tostring(windower and windower.prim ~= nil)..' prim_ok='..tostring(prim_ok))
end

windower.register_event('load', function()
    make_overlay()
    local info = windower.ffxi.get_info()
    if info and info.zone then load_trail(info.zone) end
end)

windower.register_event('unload', function()
    save_trail()
    if overlay and overlay.destroy then overlay:destroy() end
    if test_overlay and test_overlay.destroy then test_overlay:destroy() end
    clear_primitives()
end)

windower.register_event('zone change', function(new_zone)
    save_trail()
    load_trail(new_zone)
end)

windower.register_event('prerender', tick)

windower.register_event('addon command', function(command, ...)
    command = command and command:lower() or 'help'
    local args = {...}

    if command == 'show' then
        settings.visible = true
        settings.enabled = true
        prim_ok = nil
        if test_overlay and test_overlay.destroy then test_overlay:destroy() end
        test_overlay = nil
        clear_primitives()
        set_visible(true)
    elseif command == 'hide' then
        settings.visible = false
        set_visible(false)
        clear_primitives()
    elseif command == 'toggle' then
        settings.visible = not settings.visible
        prim_ok = nil
        if settings.visible then
            settings.enabled = true
            if test_overlay and test_overlay.destroy then test_overlay:destroy() end
            test_overlay = nil
            clear_primitives()
            set_visible(true)
        else
            set_visible(false)
            clear_primitives()
        end
    elseif command == 'reset' then
        reset_trail()
        notice('Trail completely reset. Origin established at current position.')
    elseif command == 'clear' then
        clear_trail()
        notice('Breadcrumbs cleared. Start location kept intact.')
    elseif command == 'save' then
        save_trail()
        notice('Trail saved.')
    elseif command == 'center' then
        settings.center_on_player = not settings.center_on_player
        notice('Center on player: '..tostring(settings.center_on_player))
    elseif command == 'backtrack' then
        settings.erase_on_backtrack = not settings.erase_on_backtrack
        notice('Erase on backtrack: '..tostring(settings.erase_on_backtrack))
    elseif command == 'status' or command == 'stats' or command == 'debug' then
        show_status()
    elseif command == 'test' then
        chat('test command received.')
        if test_overlay and test_overlay.destroy then test_overlay:destroy() end

        test_overlay = texts.new('TRAILMAP TEST\nIf you see this, rendering works.', {
            pos = {x = 40, y = 80},
            text = {
                visible = true,
                font = 'Consolas',
                size = 16,
                red = 255,
                green = 255,
                blue = 255,
                alpha = 255,
            },
            bg = {
                visible = true,
                red = 0,
                green = 0,
                blue = 0,
                alpha = 255,
            },
            flags = {
                draggable = true,
            },
        })

        test_overlay:pos(40, 80)
        if test_overlay.bg_visible then test_overlay:bg_visible(true) end
        if test_overlay.bg_alpha then test_overlay:bg_alpha(255) end
        if test_overlay.show then
            test_overlay:show()
        end
        if test_overlay.visible then
            test_overlay:visible(true)
        end

        if overlay then
            overlay:pos(40, 160)
            overlay:text('TRAILMAP MAP OVERLAY TEST')
            if overlay.show then overlay:show() end
            if overlay.visible then overlay:visible(true) end
        end
    elseif command == 'primtest' then
        clear_primitives()
        prim_ok = nil
        if prim_rect(prim_prefix..'test', 40, 80, 320, 120, 255, 0, 0, 0) then
            prim_rect(prim_prefix..'cell_test_a', 60, 105, 40, 40, 255, 255, 80, 80)
            prim_rect(prim_prefix..'cell_test_b', 110, 105, 40, 40, 255, 90, 190, 255)
            prim_rect(prim_prefix..'cell_test_c', 160, 105, 40, 40, 255, 255, 235, 90)
            chat('primitive test drawn at 40,80.')
        else
            chat('primitive API was not available or failed.')
        end
    elseif command == 'reloadbox' then
        make_overlay()
        notice('trailmap overlay rebuilt.')
    elseif command == 'pos' then
        settings.pos.x = tonumber(args[1]) or settings.pos.x
        settings.pos.y = tonumber(args[2]) or settings.pos.y
        settings.x = settings.pos.x
        settings.y = settings.pos.y
        if overlay then overlay:pos(settings.pos.x, settings.pos.y) end
    elseif command == 'size' then
        settings.width = tonumber(args[1]) or settings.width
        settings.height = tonumber(args[2]) or settings.height
        make_overlay()
    elseif command == 'scale' then
        settings.scale = tonumber(args[1]) or settings.scale
        normalize_settings()
    elseif command == 'eraser' or command == 'erase' or command == 'radius' then
        local radius = tonumber(args[1])
        if radius then
            settings.erase_radius = radius
            settings.erase_on_backtrack = true
        else
            settings.erase_on_backtrack = not settings.erase_on_backtrack
        end
        normalize_settings()
        chat('eraser='..tostring(settings.erase_on_backtrack)..' radius='..tostring(settings.erase_radius)..' cells.')
    elseif command == 'opacity' then
        settings.opacity = tonumber(args[1]) or settings.opacity
        normalize_settings()
        if overlay and overlay.bg_alpha then overlay:bg_alpha(settings.opacity) end
    else
        show_help()
        return
    end

    config.save(settings)
end)

make_overlay()
local startup_info = windower.ffxi.get_info()
if startup_info and startup_info.zone then
    load_trail(startup_info.zone)
end